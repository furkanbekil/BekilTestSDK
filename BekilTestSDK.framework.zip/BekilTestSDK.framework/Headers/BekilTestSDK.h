//
//  BekilTestSDK.h
//  BekilTestSDK
//
//  Created by Furkan Bekil on 6.06.2018.
//  Copyright © 2018 Furkan Bekil. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for BekilTestSDK.
FOUNDATION_EXPORT double BekilTestSDKVersionNumber;

//! Project version string for BekilTestSDK.
FOUNDATION_EXPORT const unsigned char BekilTestSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BekilTestSDK/PublicHeader.h>


